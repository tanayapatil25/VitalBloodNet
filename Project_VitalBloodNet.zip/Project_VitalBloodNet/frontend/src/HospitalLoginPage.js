import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './HospitalLoginPage.css'; // Importing the CSS file

function HospitalLoginPage() {
  const [contact, setContact] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    const response = await fetch('/hospitals/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ contact, password }),
    });

    if (response.ok) {
      navigate('/dashboard/hospital');
    } else {
      alert('Login failed!');
    }
  };

  return (
    <div className="hospital-login-page">
      <div className="login-box">
        <h2 className="login-title">Hospital Login</h2>
        <div className="input-container">
          <input
            type="text"
            placeholder="Contact Number"
            value={contact}
            onChange={(e) => setContact(e.target.value)}
          />
        </div>
        <div className="input-container">
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button className="login-button" onClick={handleLogin}>
          Login
        </button>
        <p className="register-link" onClick={() => navigate('/register/hospital')}>
          Don't have an account? Register
        </p>
      </div>
    </div>
  );
}

export default HospitalLoginPage;
