import React from 'react';
import { useNavigate } from 'react-router-dom';
import './UserDashboard.css';

function UserDashboard() {
  const navigate = useNavigate();

  return (
    <div className="dashboard-container">
      <div className="dashboard-content">
        <h2>User Dashboard</h2>
        <div className="button-group">
          <button onClick={() => navigate('/request')}>Make a Request</button>
          <button onClick={() => navigate('/donation')}>Make a Donation</button>
          <button onClick={() => navigate('/view-requests')}>View Requests</button>
          <button onClick={() => navigate('/view-donations')}>View Donations</button>
        </div>
      </div>
    </div>
  );
}

export default UserDashboard;
