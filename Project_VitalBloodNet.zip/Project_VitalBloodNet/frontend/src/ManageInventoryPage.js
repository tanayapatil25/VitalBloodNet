import React, { useState, useEffect } from 'react';
import ClipLoader from 'react-spinners/ClipLoader';

function ManageInventoryPage({ bloodBankId }) {
  const [inventory, setInventory] = useState({});
  const [bloodGroup, setBloodGroup] = useState('');
  const [quantity, setQuantity] = useState('');
  const [loading, setLoading] = useState(true); // Loading state

  useEffect(() => {
    fetchInventory();
  }, []);

  const fetchInventory = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/bloodbanks/${bloodBankId}/inventory`);
      if (response.ok) {
        const data = await response.json();
        setInventory(data);
      } else {
        alert('Failed to fetch inventory.');
      }
    } catch (error) {
      console.error('Error fetching inventory:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateInventory = async () => {
    try {
      const newQuantities = { [bloodGroup]: parseInt(quantity, 10) };
      const response = await fetch(`/bloodbanks/${bloodBankId}/update-inventory`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newQuantities),
      });

      if (response.ok) {
        alert('Inventory updated successfully!');
        fetchInventory();
      } else {
        alert('Failed to update inventory.');
      }
    } catch (error) {
      console.error('Error updating inventory:', error);
    }
  };

  return (
    <div className="inventory-page">
      <h2>Manage Inventory</h2>
      {loading ? (
        <ClipLoader size={50} color={"#123abc"} loading={loading} />
      ) : (
        <div>
          <select value={bloodGroup} onChange={(e) => setBloodGroup(e.target.value)}>
            <option value="">Select Blood Group</option>
            {/* Add other blood groups */}
          </select>
          <input
            type="number"
            placeholder="Quantity"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
          />
          <button onClick={handleUpdateInventory}>Update Inventory</button>
          <h3>Current Inventory</h3>
          <ul>
            {Object.entries(inventory).map(([group, qty]) => (
              <li key={group}>
                {group}: {qty} units
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default ManageInventoryPage;

