import React from 'react';
import { useNavigate } from 'react-router-dom';
import './BloodBankDashboard.css';

function BloodBankDashboard() {
  const navigate = useNavigate();

  return (
    <div className="dashboard-container">
      <div className="dashboard-content">
        <h2>Blood Bank Dashboard</h2>
        <div className="button-group">
          <button onClick={() => navigate('/inventory')}>Manage Inventory</button>
          <button onClick={() => navigate('/view-requests')}>View Requests</button>
          <button onClick={() => navigate('/view-donations')}>View Donations</button>
        </div>
      </div>
    </div>
  );
}

export default BloodBankDashboard;
