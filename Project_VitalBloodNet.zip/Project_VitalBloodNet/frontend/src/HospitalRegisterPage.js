import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './HospitalRegisterPage.css';

function HospitalRegisterPage() {
  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [contact, setContact] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleRegister = async () => {
    const response = await fetch('/hospitals/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name,
        city,
        address,
        contact,
        password,
      }),
    });

    if (response.ok) {
      alert('Registration successful!');
      navigate('/login/hospital');
    } else {
      alert('Failed to register.');
    }
  };

  return (
    <div className="hospital-register-container">
      <div className="register-box">
        <h2>Hospital Registration</h2>
        <div className="input-group">
          <input 
            type="text" 
            placeholder="Hospital Name" 
            value={name} 
            onChange={(e) => setName(e.target.value)} 
          />
        </div>
        <div className="input-group">
          <input 
            type="text" 
            placeholder="City" 
            value={city} 
            onChange={(e) => setCity(e.target.value)} 
          />
        </div>
        <div className="input-group">
          <input 
            type="text" 
            placeholder="Address" 
            value={address} 
            onChange={(e) => setAddress(e.target.value)} 
          />
        </div>
        <div className="input-group">
          <input 
            type="text" 
            placeholder="Contact Number" 
            value={contact} 
            onChange={(e) => setContact(e.target.value)} 
          />
        </div>
        <div className="input-group">
          <input 
            type="password" 
            placeholder="Password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
          />
        </div>
        <button onClick={handleRegister} className="register-btn">Register</button>
      </div>
    </div>
  );
}

export default HospitalRegisterPage;
