import React from 'react';
import { useNavigate } from 'react-router-dom';
import './HomePage.css'; // Ensure you have this CSS file for styling
import logo from './logo.png'; // Ensure logo.png is in the same directory or adjust the path accordingly

function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="homepage">
      <header className="hero">
        <div className="logo-container">
          <img src={logo} alt="VitalBloodNet Logo" className="logo" />
        </div>
        <h1 className="hero-title">VitalBloodNet</h1>
        <p className="hero-subtitle">Your reliable blood donation and request platform.</p>
      </header>
      <section className="info-section">
        <div className="info-card">
          <h2 className="info-title">Login as User</h2>
          <p className="info-description">Access your dashboard and manage your blood donation activities.</p>
          <button className="info-button" onClick={() => navigate('/login/user')}>Login as User</button>
        </div>
        <div className="info-card">
          <h2 className="info-title">Login as Hospital</h2>
          <p className="info-description">Request blood and manage hospital blood bank activities.</p>
          <button className="info-button" onClick={() => navigate('/login/hospital')}>Login as Hospital</button>
        </div>
        <div className="info-card">
          <h2 className="info-title">Login as Blood Bank</h2>
          <p className="info-description">Manage your blood bank inventory and process requests.</p>
          <button className="info-button" onClick={() => navigate('/login/bloodbank')}>Login as Blood Bank</button>
        </div>
      </section>
    </div>
  );
}

export default HomePage;
