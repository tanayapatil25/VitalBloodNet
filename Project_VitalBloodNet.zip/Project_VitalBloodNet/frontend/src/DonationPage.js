import React, { useState, useEffect } from 'react';
import axios from 'axios';

function DonationForm() {
    const [bloodBanks, setBloodBanks] = useState([]);
    const [donation, setDonation] = useState({
        donor: '',
        receiver: '',
        bloodBank: '',
        bloodType: '',
        quantity: '',
        donationDate: '',
        isCompleted: false,
    });

    useEffect(() => {
        // Fetch blood banks
        axios.get('/api/bloodbanks') // Adjust the endpoint if needed
            .then(response => {
                setBloodBanks(response.data);
            })
            .catch(error => {
                console.error('Error fetching blood banks', error);
            });
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setDonation(prevDonation => ({
            ...prevDonation,
            [name]: value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post('/api/donations/create', donation)
            .then(response => {
                alert('Donation created successfully');
                // Optionally, reset the form or redirect
            })
            .catch(error => {
                console.error('Error creating donation', error);
            });
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label>Donor</label>
                <input
                    type="text"
                    name="donor"
                    value={donation.donor}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label>Receiver</label>
                <input
                    type="text"
                    name="receiver"
                    value={donation.receiver}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label>Blood Bank</label>
                <select
                    name="bloodBank"
                    value={donation.bloodBank}
                    onChange={handleChange}
                >
                    <option value="">Select a Blood Bank</option>
                    {bloodBanks.map(bloodBank => (
                        <option key={bloodBank.id} value={bloodBank.id}>
                            {bloodBank.name}
                        </option>
                    ))}
                </select>
            </div>
            <div>
                <label>Blood Type</label>
                <input
                    type="text"
                    name="bloodType"
                    value={donation.bloodType}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label>Quantity</label>
                <input
                    type="number"
                    name="quantity"
                    value={donation.quantity}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label>Donation Date</label>
                <input
                    type="date"
                    name="donationDate"
                    value={donation.donationDate}
                    onChange={handleChange}
                />
            </div>
            <div>
                <button type="submit">Submit</button>
            </div>
        </form>
    );
}

export default DonationForm;
