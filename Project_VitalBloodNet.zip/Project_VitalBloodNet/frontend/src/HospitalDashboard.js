import React from 'react';
import { useNavigate } from 'react-router-dom';
import './HospitalDashboard.css';

function HospitalDashboard() {
  const navigate = useNavigate();

  return (
    <div className="dashboard-container">
      <div className="dashboard-content">
        <h2>Hospital Dashboard</h2>
        <div className="button-group">
          <button onClick={() => navigate('/request')}>Make a Request</button>
          <button onClick={() => navigate('/view-requests')}>View Requests</button>
        </div>
      </div>
    </div>
  );
}

export default HospitalDashboard;

