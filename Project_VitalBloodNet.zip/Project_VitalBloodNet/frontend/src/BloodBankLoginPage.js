import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './BloodBankLoginPage.css'; // Import CSS for styling

function BloodBankLoginPage() {
  const [contact, setContact] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const response = await fetch('/bloodbanks/login?' + new URLSearchParams({ contact, password }), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        // Assuming a successful login redirects to a dashboard
        navigate('/dashboard/bloodbank');
      } else {
        const errorData = await response.json();
        alert(`Login failed: ${errorData.message || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Error during login:', error);
      alert('An error occurred during login. Please try again later.');
    }
  };

  return (
    <div className="bloodbank-login-page">
      <div className="login-container">
        <h2>Blood Bank Login</h2>
        <form className="login-form">
          <input
            type="text"
            placeholder="Contact Number"
            value={contact}
            onChange={(e) => setContact(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button type="button" onClick={handleLogin}>
            Login
          </button>
          <p onClick={() => navigate('/register/bloodbank')}>
            Don't have an account? Register
          </p>
        </form>
      </div>
    </div>
  );
}

export default BloodBankLoginPage;
