import React from 'react';
import { useNavigate } from 'react-router-dom';
import './RequestPage.css'; // Make sure you have this CSS file

function RequestPage() {
  const navigate = useNavigate();

  return (
    <div className="request-page">
      <div className="request-page-overlay">
        <div className="request-page-content">
          <h2>Request Blood</h2>
          <p className="description">Select an option below to request blood:</p>
          <div className="request-options">
            <button className="option-button" onClick={() => navigate('/request/user')}>
              Request from User
            </button>
            <button className="option-button" onClick={() => navigate('/request/bloodbank')}>
              Request from Blood Bank
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default RequestPage;
