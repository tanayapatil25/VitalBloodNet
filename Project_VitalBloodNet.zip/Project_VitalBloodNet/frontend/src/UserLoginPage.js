import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './UserLoginPage.css'; // Ensure this CSS file is included

function UserLoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    const response = await fetch('/users/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    });
    if (response.ok) {
      navigate('/dashboard/user');
    } else {
      alert('Login failed!');
    }
  };

  return (
    <div className="login-page">
      <div className="login-box">
        <h2>User Login</h2>
        <input 
          type="email" 
          placeholder="Email" 
          value={email} 
          onChange={(e) => setEmail(e.target.value)} 
          className="input-field"
        />
        <input 
          type="password" 
          placeholder="Password" 
          value={password} 
          onChange={(e) => setPassword(e.target.value)} 
          className="input-field"
        />
        <button type="button" className="login-button" onClick={handleLogin}>Login</button>
        <p className="register-link" onClick={() => navigate('/register/user')}>Don't have an account? Register</p>
      </div>
    </div>
  );
}

export default UserLoginPage;
