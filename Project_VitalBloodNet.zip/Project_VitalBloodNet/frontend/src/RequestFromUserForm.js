import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function RequestPageToUser() {
  const [bloodType, setBloodType] = useState('');
  const [quantity, setQuantity] = useState('');
  const [bloodBankId, setBloodBankId] = useState('');
  const [city, setCity] = useState('');
  const navigate = useNavigate();

  const handleRequest = async () => {
    const requestData = {
      bloodType,
      quantity,
      bloodBank: { id: bloodBankId },
      city,
      requestDate: new Date().toISOString().split('T')[0], // Set to current date
    };

    const response = await fetch('/requests/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestData),
    });

    if (response.ok) {
      alert('Request created successfully!');
      navigate('/dashboard/user');
    } else {
      const error = await response.json();
      alert(`Failed to create request: ${error.message || 'Unknown error'}`);
    }
  };

  return (
    <div className="request-page">
      <h2>Create a Request to Blood Bank</h2>
      <form className="request-form">
        <select
          value={bloodType}
          onChange={(e) => setBloodType(e.target.value)}
          required
        >
          <option value="">Select Blood Type</option>
          <option value="A_POS">A+</option>
          <option value="A_NEG">A-</option>
          <option value="B_POS">B+</option>
          <option value="B_NEG">B-</option>
          <option value="AB_POS">AB+</option>
          <option value="AB_NEG">AB-</option>
          <option value="O_POS">O+</option>
          <option value="O_NEG">O-</option>
        </select>
        <input
          type="number"
          placeholder="Quantity"
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Blood Bank ID"
          value={bloodBankId}
          onChange={(e) => setBloodBankId(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="City"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          required
        />
        <button type="button" onClick={handleRequest}>Submit Request</button>
      </form>
    </div>
  );
}

export default RequestPageToUser;
