import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './UserRegistrationPage.css'; // Ensure you have this CSS file

function UserRegistrationPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [dob, setDob] = useState('');
  const [city, setCity] = useState('');
  const [bloodGroup, setBloodGroup] = useState('');
  const [isActiveDonor, setIsActiveDonor] = useState(false);
  const navigate = useNavigate();

  const handleRegister = async () => {
    // API call to register the user
    const response = await fetch('/users/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name,
        email,
        password,
        phoneNumber,
        dob,
        city,
        bloodGroup,
        isActiveDonor,
      }),
    });

    if (response.ok) {
      alert('Registration successful!');
      navigate('/login'); // Redirect to login or another page after successful registration
    } else {
      alert('Failed to register.');
    }
  };

  return (
    <div className="registration-page">
      <div className="form-container">
        <h2>Register</h2>
        <form className="registration-form">
          <input
            type="text"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <input
            type="text"
            placeholder="Phone Number"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
          />
          <input
            type="date"
            placeholder="Date of Birth"
            value={dob}
            onChange={(e) => setDob(e.target.value)}
          />
          <input
            type="text"
            placeholder="City"
            value={city}
            onChange={(e) => setCity(e.target.value)}
          />
          <select
            value={bloodGroup}
            onChange={(e) => setBloodGroup(e.target.value)}
          >
            <option value="">Select Blood Group</option>
            <option value="A_POS">A+</option>
            <option value="A_NEG">A-</option>
            <option value="B_POS">B+</option>
            <option value="B_NEG">B-</option>
            <option value="AB_POS">AB+</option>
            <option value="AB_NEG">AB-</option>
            <option value="O_POS">O+</option>
            <option value="O_NEG">O-</option>
          </select>
          <label>
            <input
              type="checkbox"
              checked={isActiveDonor}
              onChange={(e) => setIsActiveDonor(e.target.checked)}
            />
            I am an active donor
          </label>
          <button type="button" onClick={handleRegister}>
            Register
          </button>
        </form>
      </div>
    </div>
  );
}

export default UserRegistrationPage;
