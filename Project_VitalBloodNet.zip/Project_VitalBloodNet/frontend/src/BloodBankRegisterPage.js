import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './BloodBankRegisterPage.css'; // Import the CSS file for styling

function BloodBankRegisterPage() {
  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [contact, setContact] = useState('');
  const [password, setPassword] = useState('');
  const [availableBloodTypes, setAvailableBloodTypes] = useState([]);
  const navigate = useNavigate();

  const handleRegister = async () => {
    const response = await fetch('/bloodbanks/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name,
        city,
        address,
        contact,
        password,
        availableBloodTypes,
      }),
    });

    if (response.ok) {
      alert('Registration successful!');
      navigate('/login/bloodbank');
    } else {
      alert('Failed to register.');
    }
  };

  const handleBloodTypeChange = (e) => {
    const value = e.target.value;
    setAvailableBloodTypes(
      e.target.checked
        ? [...availableBloodTypes, value]
        : availableBloodTypes.filter(bloodType => bloodType !== value)
    );
  };

  return (
    <div className="bloodbank-register-page">
      <div className="register-container">
        <h2>Register Blood Bank</h2>
        <form className="register-form">
          <input
            type="text"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <input
            type="text"
            placeholder="City"
            value={city}
            onChange={(e) => setCity(e.target.value)}
          />
          <input
            type="text"
            placeholder="Address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />
          <input
            type="text"
            placeholder="Contact Number"
            value={contact}
            onChange={(e) => setContact(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <fieldset>
            <legend>Available Blood Types</legend>
            {['A_POS', 'A_NEG', 'B_POS', 'B_NEG', 'AB_POS', 'AB_NEG', 'O_POS', 'O_NEG'].map(bloodType => (
              <label key={bloodType}>
                <input
                  type="checkbox"
                  value={bloodType}
                  onChange={handleBloodTypeChange}
                />
                {bloodType}
              </label>
            ))}
          </fieldset>
          <button type="button" onClick={handleRegister}>
            Register
          </button>
        </form>
      </div>
    </div>
  );
}

export default BloodBankRegisterPage;
