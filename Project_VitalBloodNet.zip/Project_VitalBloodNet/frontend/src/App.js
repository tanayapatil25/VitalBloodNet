import React from 'react';
import { Route, Routes } from 'react-router-dom';
import HomePage from './HomePage';
import UserLoginPage from './UserLoginPage';
import HospitalLoginPage from './HospitalLoginPage';
import BloodBankLoginPage from './BloodBankLoginPage';
import UserRegisterPage from './UserRegisterPage';
import HospitalRegisterPage from './HospitalRegisterPage';
import BloodBankRegisterPage from './BloodBankRegisterPage';
import UserDashboard from './UserDashboard';
import HospitalDashboard from './HospitalDashboard';
import BloodBankDashboard from './BloodBankDashboard';
import RequestPage from './RequestPage';
import DonationPage from './DonationPage';
import ManageInventoryPage from './ManageInventoryPage';
import RequestFromUserForm from './RequestFromUserForm';
import RequestFromBloodBankForm from './RequestFromBloodBankForm';

function App() {
  return (
    <div className="app-container">
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login/user" element={<UserLoginPage />} />
        <Route path="/login/hospital" element={<HospitalLoginPage />} />
        <Route path="/login/bloodbank" element={<BloodBankLoginPage />} />
        <Route path="/register/user" element={<UserRegisterPage />} />
        <Route path="/register/hospital" element={<HospitalRegisterPage />} />
        <Route path="/register/bloodbank" element={<BloodBankRegisterPage />} />
        <Route path="/dashboard/user" element={<UserDashboard />} />
        <Route path="/dashboard/hospital" element={<HospitalDashboard />} />
        <Route path="/dashboard/bloodbank" element={<BloodBankDashboard />} />
        <Route path="/request" element={<RequestPage />} />
        <Route path="/request/user" element={<RequestFromUserForm />} />
        <Route path="/request/bloodbank" element={<RequestFromBloodBankForm />} />
        <Route path="/donation" element={<DonationPage />} />
        <Route path="/inventory" element={<ManageInventoryPage />} />
      </Routes>
    </div>
  );
}

export default App;





