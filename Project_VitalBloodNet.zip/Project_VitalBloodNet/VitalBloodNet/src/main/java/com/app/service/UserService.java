package com.app.service;

import com.app.entities.User;
import com.app.repository.UserRepository;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    public User registerUser(User user) {
        // Check if email already exists
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new IllegalArgumentException("Email already registered");
        }
        // Save the user to the database
        return userRepository.save(user);
    }
    
    public User loginUser(String email,String password) {
        return userRepository.findByEmailAndPassword(email,password);
    }
    
    public User updateUser(User user) {
        return userRepository.save(user);
    }
    
    public List<User> getUsersByCityAndActiveDonor(String city) {
        return userRepository.findByCityIgnoreCaseAndIsActiveDonorTrue(city.trim());
    }
}


