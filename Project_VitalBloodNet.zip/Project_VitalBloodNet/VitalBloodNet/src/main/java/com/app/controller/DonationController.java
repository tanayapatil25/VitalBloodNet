package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.DonationDto;
import com.app.entities.BloodBank;
import com.app.entities.Donation;
import com.app.entities.User;
import com.app.repository.BloodBankRepository;
import com.app.repository.UserRepository;
import com.app.service.DonationService;

@RestController
@RequestMapping("/donations")
public class DonationController {

	@Autowired
    private DonationService donationService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BloodBankRepository bloodBankRepository;

//    @PostMapping("/create")
//    public Donation createDonation(@RequestBody DonationDto donationDto, @AuthenticationPrincipal UserDetails userDetails) {
//        User donor = userRepository.findByEmail(userDetails.getUsername());
//        BloodBank bloodBank = bloodBankRepository.findById(donationDto.getBloodBankId())
//            .orElseThrow(() -> new ResourceNotFoundException("BloodBank not found"));
//
//        Donation donation = new Donation();
//        donation.setDonor(donor);
//        donation.setBloodBank(bloodBank);
//        donation.setBloodType(donationDto.getBloodType());
//        donation.setQuantity(donationDto.getQuantity());
//        donation.setDonationDate(donationDto.getDonationDate());
//
//        return donationService.createDonation(donation);
//    }

    @GetMapping("/bloodbank/{bloodBankId}")
    public List<Donation> getDonationsByBloodBank(@PathVariable Long bloodBankId) {
        return donationService.getDonationsByBloodBank(bloodBankId);
    }
}

