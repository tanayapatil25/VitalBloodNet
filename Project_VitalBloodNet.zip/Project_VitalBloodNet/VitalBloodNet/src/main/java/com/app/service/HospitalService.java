package com.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entities.Hospital;
import com.app.repository.HospitalRepository;

@Service
public class HospitalService {

    @Autowired
    private HospitalRepository hospitalRepository;

    public Hospital registerHospital(Hospital hospital) {
        return hospitalRepository.save(hospital);
    }

    public Hospital getHospital(Long id) {
        return hospitalRepository.findById(id).orElse(null);
    }
    
    public Hospital login(String contact, String password) {
        Optional<Hospital> hospitalOptional = hospitalRepository.findByContact(contact);

        if (hospitalOptional.isPresent()) {
            Hospital hospital = hospitalOptional.get();
            if (hospital.getPassword().equals(password)) {
                return hospital;
            } else {
                throw new RuntimeException("Invalid password");
            }
        } else {
            throw new RuntimeException("Hospital not found with contact: " + contact);
        }
    }
    
    public Hospital authenticate(String contact, String password) {
        return hospitalRepository.findByContactAndPassword(contact, password);
    }
}

