package com.app.dto;

import java.time.LocalDate;

import com.app.entities.BloodGroup;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DonationDto {
    private Long bloodBankId;
    private BloodGroup bloodType;
    private Integer quantity;
    private LocalDate donationDate;
}