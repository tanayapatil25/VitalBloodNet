package com.app.dto;

import java.util.List;

import com.app.entities.BloodGroup;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BloodBankDTO {
    private Long id;
    private String name;
    private String city;
    private String address;
    private String contact;
    private List<BloodGroup> availableBloodTypes; // Ensure this is not lazy loaded

    // Constructors, Getters, and Setters
}

