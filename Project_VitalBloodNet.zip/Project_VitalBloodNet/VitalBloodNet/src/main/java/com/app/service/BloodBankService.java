package com.app.service;

import com.app.entities.BloodBank;
import com.app.entities.BloodGroup;
import com.app.entities.Inventory;
import com.app.repository.BloodBankRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

@Service
public class BloodBankService {

    @Autowired
    private BloodBankRepository bloodBankRepository;

    public BloodBank registerBloodBank(BloodBank bloodBank) {
        return bloodBankRepository.save(bloodBank);
    }

    public BloodBank getBloodBank(Long id) {
        return bloodBankRepository.findById(id).orElse(null);
    }

    public void updateInventory(Long bloodBankId, Map<BloodGroup, Integer> newQuantities) {
        BloodBank bloodBank = getBloodBank(bloodBankId);
        if (bloodBank != null) {
            Inventory inventory = bloodBank.getInventory();
            inventory.setBloodTypeQuantities(newQuantities);
            inventory.setLastUpdated(LocalDate.now());
            // Save inventory
        }
    }
    
    public BloodBank login(String contact, String password) {
        // Validate login credentials
        BloodBank bloodBank = bloodBankRepository.findByContact(contact);
        if (bloodBank != null && bloodBank.getPassword().equals(password)) {
            return bloodBank;
        }
        return null; // Return null if login fails
    }
}