package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entities.Donation;
import com.app.repository.DonationRepository;

@Service
public class DonationService {

    @Autowired
    private DonationRepository donationRepository;

    public Donation createDonation(Donation donation) {
        // Perform any additional logic or validation here if necessary
        return donationRepository.save(donation);
    }

    public List<Donation> getDonationsByBloodBank(Long bloodBankId) {
        // Retrieve donations by blood bank ID
        return donationRepository.findAll(); // Modify based on needs
    }
}

