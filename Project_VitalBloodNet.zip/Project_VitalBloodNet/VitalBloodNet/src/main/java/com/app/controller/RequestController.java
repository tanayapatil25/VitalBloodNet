package com.app.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.entities.Request;
import com.app.service.RequestService;

@RestController
@RequestMapping("/requests")
public class RequestController {

    @Autowired
    private RequestService requestService;

    @PostMapping("/create")
    public ResponseEntity<Request> createRequest(@RequestBody Request request) {
        // Set the request date to the current date if not provided
        if (request.getRequestDate() == null) {
            request.setRequestDate(LocalDate.now());
        }

        // Handle missing required fields
        if (request.getBloodType() == null || request.getQuantity() == null) {
            return ResponseEntity.badRequest().body(null);
        }

        Request createdRequest = requestService.createRequest(request);
        return ResponseEntity.ok(createdRequest);
    }
    @PutMapping("/{id}/update-status")
    public Request updateRequestStatus(@PathVariable Long id, @RequestParam String status) {
        return requestService.updateRequestStatus(id, status);
    }
}
